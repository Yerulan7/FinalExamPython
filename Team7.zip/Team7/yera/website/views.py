from flask import Blueprint, render_template, request, flash, redirect, url_for, jsonify, send_file
from flask_login import login_required, current_user
from .models import Reservation, User, Contact
from . import db
import pandas as pd


views = Blueprint("views", __name__)


@views.route("/")
@views.route("/home")
@login_required
def home():
    reservations = Reservation.query.all()
    return render_template("home.html", user=current_user, reservations=reservations)


@views.route("/myreservations")
@login_required
def myreservations():
    reservations = Reservation.query.all()
    return render_template("myreservations.html", user=current_user, reservations=reservations)


@views.route("/contactme", methods=['GET', 'POST'])
@login_required
def contactme():
    if request.method == "POST":
        message = request.form.get('message')
        email = request.form.get('email')
        username = request.form.get('username')

        if not message:
            flash('Message cannot be empty', category='error')
        elif not email:
            flash('Email cannot be empty', category='error')
        else:
            new_message = Contact(email=email, username=username, message=message)
            db.session.add(new_message)
            db.session.commit()
            flash('Message is sent!', category='success')
            return redirect(url_for('views.home'))

    return render_template('contact.html', user=current_user)


@views.route("/create_reservation", methods=['GET', 'POST'])
@login_required
def create_reservation():
    if request.method == "POST":
        guests = request.form.get('guests')
        phone = request.form.get('phone')
        text = request.form.get('text')
        date = request.form.get('date')

        if not phone:
            flash('Phone number cannot be empty', category='error')
        elif not guests:
            flash('Guests number cannot be empty', category='error')
        else:
            reservations = Reservation(guests = guests, phone = phone, text=text, date=date, author=current_user.id)
            db.session.add(reservations)
            db.session.commit()
            flash('Reservation is created!', category='success')
            return redirect(url_for('views.home'))

    return render_template('create_reservation.html', user=current_user)


@views.route("/delete-reservation/<id>")
@login_required
def delete_reservation(id):
    reservation = Reservation.query.filter_by(id=id).first()

    if not reservation:
        flash("Reservation does not exist.", category='error')
    elif current_user.id != reservation.id:
        flash('You do not have permission to delete this reservation.', category='error')
    else:
        db.session.delete(reservation)
        db.session.commit()
        flash('Reservation deleted.', category='success')

    return redirect(url_for('views.home'))


@views.route("/reservations/<username>")
@login_required
def reservations(username):
    user = User.query.filter_by(username=username).first()

    if not user:
        return redirect(url_for('views.home'))

    reservations = user.reservations
    return render_template("reservations.html", user=current_user, reservations=reservations, username=username)


@views.route("/download")
def download_file():
    file = 'catalog.pdf'
    return send_file(file, as_attachment=True)
